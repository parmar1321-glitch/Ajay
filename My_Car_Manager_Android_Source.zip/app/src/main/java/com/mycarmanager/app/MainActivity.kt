package com.mycarmanager.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.work.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

data class Vehicle(
    val id: Long = System.currentTimeMillis(),
    val name: String,
    val registration: String,
    val type: String,
    val insurance: String = "",
    val fitness: String = "",
    val puc: String = "",
    val permit: String = "",
    val tax: String = "",
    val serviceDate: String = "",
    val serviceKm: String = "",
    val currentKm: String = "",
    val notes: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        val requestPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.NOT_REQUIRED).build()
        val work = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS)
            .setConstraints(constraints).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("vehicle_due_reminders", ExistingPeriodicWorkPolicy.UPDATE, work)
        setContent { CarManagerApp() }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("car_due", "Vehicle reminders", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val vehicles = Store.load(applicationContext)
        val today = LocalDateUtil.today()
        val due = mutableListOf<String>()
        vehicles.forEach { v ->
            listOf("Insurance" to v.insurance, "Fitness" to v.fitness, "PUC" to v.puc,
                "Permit" to v.permit, "Tax" to v.tax).forEach { (label, date) ->
                val days = LocalDateUtil.daysUntil(date)
                if (days != null && days in 0..30) due.add("${v.registration}: $label ${if (days == 0) "due today" else "due in $days days"}")
            }
            val serviceDays = LocalDateUtil.daysUntil(v.serviceDate)
            if (serviceDays != null && serviceDays in 0..7) due.add("${v.registration}: service due ${if (serviceDays == 0) "today" else "in $serviceDays days"}")
            val dueKm = v.serviceKm.toIntOrNull()
            val current = v.currentKm.toIntOrNull()
            if (dueKm != null && current != null && current >= dueKm) due.add("${v.registration}: service kilometer target reached")
        }
        if (due.isNotEmpty()) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val builder = if (Build.VERSION.SDK_INT >= 26)
                android.app.Notification.Builder(applicationContext, "car_due")
            else android.app.Notification.Builder(applicationContext)
            manager.notify(1001, builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("My Car Manager: due reminders")
                .setContentText(due.take(2).joinToString(" • "))
                .setStyle(android.app.Notification.BigTextStyle().bigText(due.joinToString("\n")))
                .build())
        }
        return Result.success()
    }
}

object LocalDateUtil {
    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    fun today(): String = fmt.format(Date())
    fun daysUntil(value: String): Int? {
        return try {
            val target = fmt.parse(value) ?: return null
            val now = fmt.parse(today()) ?: return null
            ((target.time - now.time) / 86400000L).toInt()
        } catch (_: Exception) { null }
    }
}

object Store {
    private const val PREF = "car_manager"
    private const val KEY = "vehicles"
    private val gson = Gson()
    fun load(context: Context): MutableList<Vehicle> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val type = object : TypeToken<MutableList<Vehicle>>() {}.type
        return try { gson.fromJson<MutableList<Vehicle>>(raw, type) ?: mutableListOf() } catch (_: Exception) { mutableListOf() }
    }
    fun save(context: Context, vehicles: List<Vehicle>) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, gson.toJson(vehicles)).apply()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CarManagerApp() {
    val context = LocalContext.current
    var vehicles by remember { mutableStateOf(Store.load(context)) }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Vehicle?>(null) }
    val navy = Color(0xFF172B4D)
    val blue = Color(0xFF2457C5)
    MaterialTheme(colorScheme = lightColorScheme(primary = blue, background = Color(0xFFF5F7FB))) {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("My Car Manager", fontWeight = FontWeight.Bold, color = navy)
                        Text("All your vehicles in one place", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                }, actions = { TextButton(onClick = { showAdd = true }) { Text("+ Add vehicle") } })
            },
            floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }) { Text("+") } }
        ) { padding ->
            LazyColumn(Modifier.fillMaxSize().background(Color(0xFFF5F7FB)).padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryCard("Vehicles", vehicles.size.toString(), Modifier.weight(1f))
                        SummaryCard("Due / upcoming", upcomingCount(vehicles).toString(), Modifier.weight(1f))
                    }
                }
                item { Text("Your vehicles", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = navy) }
                if (vehicles.isEmpty()) item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("No vehicles added yet", fontWeight = FontWeight.SemiBold)
                            Text("Tap + Add vehicle to create your first vehicle profile.", color = Color.Gray)
                        }
                    }
                }
                items(vehicles, key = { it.id }) { v ->
                    VehicleCard(v, onClick = { selected = v }, onDelete = {
                        vehicles = vehicles.filterNot { it.id == v.id }; Store.save(context, vehicles)
                    })
                }
                item {
                    Text("Reminder rules", fontWeight = FontWeight.Bold, color = navy)
                    Text("Insurance / Fitness / Permit / Tax: 30 days. PUC: 15 days. Service: 7 days and target kilometer. Android checks once daily.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Text("WhatsApp: use the Share reminder button on a vehicle to prepare a message. You choose the recipient and send it.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
        }
        if (showAdd) VehicleEditor(onDismiss = { showAdd = false }, onSave = {
            vehicles = vehicles + it; Store.save(context, vehicles); showAdd = false
        })
        selected?.let { v ->
            VehicleDetails(v, onDismiss = { selected = null }, onShare = { shareReminder(context, v) }, onSave = { updated ->
                vehicles = vehicles.map { if (it.id == updated.id) updated else it }; Store.save(context, vehicles); selected = updated
            })
        }
    }
}

@Composable
fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color(0xFF2457C5))
            Text(label, style = MaterialTheme.typography.labelMedium, color = Color.Gray)
        }
    }
}

@Composable
fun VehicleCard(v: Vehicle, onClick: () -> Unit, onDelete: () -> Unit) {
    val due = listOf("Insurance" to v.insurance, "Fitness" to v.fitness, "PUC" to v.puc, "Permit" to v.permit, "Tax" to v.tax)
        .mapNotNull { (n,d) -> LocalDateUtil.daysUntil(d)?.let { n to it } }
    val nearest = due.minByOrNull { it.second }
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(v.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("${v.registration} • ${v.type}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = onDelete) { Text("Delete", color = Color(0xFFB3261E)) }
            }
            if (nearest != null) {
                val status = when { nearest.second < 0 -> "${nearest.first} expired ${-nearest.second} days ago"; nearest.second == 0 -> "${nearest.first} due today"; else -> "${nearest.first} due in ${nearest.second} days" }
                Text(status, color = if (nearest.second <= 7) Color(0xFFB3261E) else Color(0xFF9A6700), fontWeight = FontWeight.SemiBold)
            } else Text("Tap to view documents and service details", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleEditor(initial: Vehicle? = null, onDismiss: () -> Unit, onSave: (Vehicle) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var reg by remember { mutableStateOf(initial?.registration ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: "Personal") }
    var insurance by remember { mutableStateOf(initial?.insurance ?: "") }
    var fitness by remember { mutableStateOf(initial?.fitness ?: "") }
    var puc by remember { mutableStateOf(initial?.puc ?: "") }
    var permit by remember { mutableStateOf(initial?.permit ?: "") }
    var tax by remember { mutableStateOf(initial?.tax ?: "") }
    var serviceDate by remember { mutableStateOf(initial?.serviceDate ?: "") }
    var serviceKm by remember { mutableStateOf(initial?.serviceKm ?: "") }
    var currentKm by remember { mutableStateOf(initial?.currentKm ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var typeExpanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initial == null) "Add vehicle" else "Edit vehicle") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 520.dp)) {
                item { Field("Vehicle name (e.g. Brezza)", name) { name = it } }
                item { Field("Registration number", reg) { reg = it } }
                item {
                    ExposedDropdownMenuBox(expanded = typeExpanded, onExpandedChange = { typeExpanded = !typeExpanded }) {
                        OutlinedTextField(type, { type = it }, label = { Text("Vehicle use") }, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = typeExpanded, onDismissRequest = { typeExpanded = false }) {
                            listOf("Personal", "Commercial").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { type = it; typeExpanded = false }) }
                        }
                    }
                }
                item { Text("Enter dates as YYYY-MM-DD", color = Color.Gray, style = MaterialTheme.typography.labelSmall) }
                item { Field("Insurance expiry", insurance) { insurance = it } }
                item { Field("Fitness expiry", fitness) { fitness = it } }
                item { Field("PUC expiry", puc) { puc = it } }
                item { Field("Permit expiry", permit) { permit = it } }
                item { Field("Road tax expiry", tax) { tax = it } }
                item { Field("Next service date", serviceDate) { serviceDate = it } }
                item { Field("Next service at KM", serviceKm, true) { serviceKm = it } }
                item { Field("Current odometer KM", currentKm, true) { currentKm = it } }
                item { Field("Notes (optional)", notes) { notes = it } }
            }
        },
        confirmButton = { TextButton(onClick = {
            if (name.isNotBlank() && reg.isNotBlank()) onSave(Vehicle(
                id = initial?.id ?: System.currentTimeMillis(), name = name.trim(), registration = reg.trim().uppercase(),
                type = type, insurance = insurance, fitness = fitness, puc = puc, permit = permit, tax = tax,
                serviceDate = serviceDate, serviceKm = serviceKm, currentKm = currentKm, notes = notes
            ))
        }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun Field(label: String, value: String, numeric: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(),
        singleLine = true, keyboardOptions = if (numeric) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default)
}

@Composable
fun VehicleDetails(v: Vehicle, onDismiss: () -> Unit, onShare: () -> Unit, onSave: (Vehicle) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(v.registration) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(v.name + " • " + v.type, fontWeight = FontWeight.Bold)
            listOf("Insurance" to v.insurance, "Fitness" to v.fitness, "PUC" to v.puc, "Permit" to v.permit, "Road tax" to v.tax, "Next service" to v.serviceDate, "Service target KM" to v.serviceKm, "Current KM" to v.currentKm).forEach { (label,value) ->
                Text("$label: ${value.ifBlank { "Not entered" }}", style = MaterialTheme.typography.bodySmall)
            }
            if (v.notes.isNotBlank()) Text("Notes: ${v.notes}")
            Text("Tap Edit to update dates and odometer details.", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
        } },
        confirmButton = { TextButton(onClick = onShare) { Text("Prepare WhatsApp") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

fun upcomingCount(vehicles: List<Vehicle>): Int = vehicles.sumOf { v ->
    listOf(v.insurance, v.fitness, v.puc, v.permit, v.tax, v.serviceDate).count { date ->
        val d = LocalDateUtil.daysUntil(date); d != null && d in 0..30
    }
}

fun shareReminder(context: Context, v: Vehicle) {
    val rows = listOf("Insurance" to v.insurance, "Fitness" to v.fitness, "PUC" to v.puc, "Permit" to v.permit, "Road tax" to v.tax, "Next service" to v.serviceDate)
        .filter { it.second.isNotBlank() }
    val message = buildString {
        append("Vehicle reminder\n${v.name} (${v.registration})\n")
        rows.forEach { (label,date) ->
            val days = LocalDateUtil.daysUntil(date)
            append("$label: $date")
            if (days != null) append(if (days < 0) " — expired ${-days} days ago" else if (days == 0) " — due today" else " — due in $days days")
            append("\n")
        }
        if (v.serviceKm.isNotBlank()) append("Service target KM: ${v.serviceKm}\n")
    }
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, message)
        setPackage("com.whatsapp")
    }
    try { context.startActivity(intent) } catch (_: Exception) {
        val fallback = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, message)
        }
        context.startActivity(android.content.Intent.createChooser(fallback, "Share vehicle reminder"))
    }
}
