# My Car Manager (Android source project)

## Included
- Multiple personal and commercial vehicle profiles
- Insurance, fitness, PUC, permit and road-tax expiry dates
- Next service date, service target odometer and current odometer fields
- Daily background reminder check using WorkManager
- Android notification channel
- WhatsApp share action that prepares a reminder message for the user to send
- Local on-device storage (SharedPreferences JSON)

## Build
1. Install Android Studio (recent version) on a computer.
2. Open this `MyCarManager` folder in Android Studio.
3. Allow Gradle sync and install the required Android SDK (API 35).
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Select Run, or use Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important limitations / setup
- This is a source project, not a precompiled APK. It needs to be built with Android Studio.
- Dates must be entered in `YYYY-MM-DD` format, e.g. `2027-03-31`.
- Android notification permission must be allowed. Android may delay periodic background work due to battery optimization; WorkManager checks approximately once per day, not at an exact minute.
- WhatsApp is not auto-sending. The app opens WhatsApp with a prepared message; you select the recipient and press Send.
- Data is stored locally on this phone. No cloud sync or automatic document scanning is included.
- For production use, add backup/export and test on the target Android version.

## Build an APK using GitHub Actions (no local Android Studio build needed)
1. Create a new GitHub repository and upload the contents of this project folder (including the hidden `.github` folder).
2. Open the repository's Actions tab.
3. Run **Build Android APK** (or push to the `main` branch).
4. When the workflow finishes, open its run and download the `My-Car-Manager-debug-apk` artifact.
5. Extract the artifact and install `app-debug.apk` on your Android phone. You may need to allow installation from your browser/file manager.
